from django.apps import AppConfig


class FlightSchedulerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flight_scheduler'
